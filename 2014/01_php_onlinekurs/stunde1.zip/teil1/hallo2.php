<html>

<body>
<strong>Hallo </strong>
<?php 

function ausgabe($suchbegriff) {
	if (strlen($suchbegriff)!=0) {
		echo (" Suchanfrage war: {$suchbegriff}");
	} else {
		echo (" keine Suchanfrage gestellt");
	}
	echo "Buchstabiert sich ";
	for ($charIndex=0; $charIndex<strlen($suchbegriff); $charIndex++) {
		 echo $suchbegriff[$charIndex]."-";
	}
	while (rand(1,5)!=3) {
		echo "Und tsch��<br>\n";
	
	}	
	
}


$studenten=array("gut"=>"Jochen St�rk", "schlecht"=>"Test");

$testArray=array("","Januar", "Februar", "M�rz");

$variablenname=rand(1,3);


ausgabe($_REQUEST['suche']);


?><br>

<form>

Suchbegriff: <input type='text' name='suche'>
<input type='submit'>
</form>
</body>
</html>
