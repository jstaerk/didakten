<html>

<body>
<strong>Hallo </strong>
<?php 

$studenten=array(451=>"Jochen St�rk", 455=>"Test");

$testArray=array("","Januar", "Februar", "M�rz");

$variablenname=rand(1,3);



echo (" Zufallsmonat war: der {$variablenname}te Monat, n�mlich {$testArray[$variablenname]} ".$variablenname2);


?><br>
</body>
</html>
