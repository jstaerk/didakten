<?php
$dateiname="dateiname.txt";

function schreibe($wert) {

	global $dateiname;
	$f=fopen($dateiname, "w");
	fwrite($f, "Wert: $wert");
	fclose($f);
}

function lese() {
	global $dateiname;
	$f=fopen($dateiname, "r");
//	$var=fread($f, filesize($dateiname));
/*	
so 
*/
	$var=fread($f, filesize($dateiname));
	fclose($f);
	
	return substr($var, 6);
}


?>
