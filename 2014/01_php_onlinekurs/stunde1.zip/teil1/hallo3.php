<html>

<body>
<strong>Hallo </strong>
<?php 

session_start();

function ausgabe($suchbegriff) {
	if (strlen($suchbegriff)!=0) {
		echo (" Suchanfrage war: {$suchbegriff} (vorherige war {$_SESSION['previous']})");
		$_SESSION['previous']=$suchbegriff;
	} else {
		echo (" keine Suchanfrage gestellt, aber vorherige war {$_SESSION['previous']}");
	}
	
}

if (isset($_SESSION['previous'])) {
echo "Du warst wohl schonmal auf dieser Seite";
} else {
echo "Hallo, Fremder!";
}


$var=55.6;

echo "var war $var, nach round ist sie ".round($var);
$studenten=array("gut"=>"Jochen St�rk", "schlecht"=>"Test");

$testArray=array("","Januar", "Februar", "M�rz");

$variablenname=rand(1,3);


ausgabe($_REQUEST['suche']);


?><br>

<form>

Suchbegriff: <input type='text' name='suche'>
<input type='submit'>
</form>
</body>
</html>
