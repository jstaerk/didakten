<html>

<body>
<strong>Hallo </strong>
<?php 
require_once('hallo4b.php');

schreibe("einen anderen String");

echo lese();

?><br>

</body>
</html>
