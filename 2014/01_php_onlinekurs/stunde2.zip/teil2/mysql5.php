<?php
$mysql=new mysqli("127.0.0.1", "root", "", "test");


if (($_REQUEST['action']=="edit")||($_REQUEST['action']=="insert")) {
	echo "<a href='?'>zur�ck</a><br>";

	
	if ($_REQUEST['action']=="edit") {
	$res=$mysql->query("SELECT * FROM nutzer WHERE id={$_REQUEST['id']}");
	if(!$res) {
		die("Maschin kaputt in Zeile ".__LINE__." von ".__FILE__);
	}
	

	$row=$res->fetch_assoc();
	} else {
		$row=array("id"=>-1);
	}
	
	echo "ID {$row["id"]}<br>
	<form>Nutzername: <input type='text' name='username' value='{$row["username"]}'>
	<br>Skype: <input type='text' name='skypename' value='{$row["skypename"]}'><br>
	<br>Password: <input type='password' name='passwort' value=''><br>
	<br>zuletzt ge�ndert: {$row["lastchange"]}<br>
	<input type='hidden' name='action' value='update'>
	<input type='hidden' name='id' value='{$row["id"]}'>
	<input type='submit'>
	</form>\n";



} else if ($_REQUEST['action']=="update") {


	$teilmitdemSet="username='".$mysql->real_escape_string($_REQUEST['username'])."', skypename='".$mysql->real_escape_string($_REQUEST['skypename'])."', passwort=PASSWORD('".$mysql->real_escape_string($_REQUEST['passwort'])."'), lastchange=NOW() ";

	if ($_REQUEST['id']!=-1)  {
		$sql="UPDATE nutzer SET $teilmitdemSet WHERE id={$_REQUEST['id']}";
	} else {
		$sql="INSERT nutzer SET $teilmitdemSet ";
	}
	$res=$mysql->query($sql);
	if(!$res) {
		die("Maschin kaputt in Zeile ".__LINE__." von ".__FILE__. " SQL $sql CODE ". $mysql->errno . " Meldung " . $mysql->error );
	}
	header("Location: ?");
	die();

} else if ($_REQUEST['action']=="delete") {


	$sql="DELETE FROM nutzer WHERE id={$_REQUEST['id']}";
	$res=$mysql->query($sql);
	if(!$res) {
		die("Maschin kaputt in Zeile ".__LINE__." von ".__FILE__. " SQL $sql CODE ". $mysql->errno . " Meldung " . $mysql->error );
	}
	header("Location: ?");
	die();

} else {

$res=$mysql->query("SELECT * FROM nutzer");
if(!$res) {
	die("Maschin kaputt in Zeile ".__LINE__." von ".__FILE__);
}



echo "<table>";
echo "<tr><th>ID</th><th>Nutzername</th><th>Skype</th><th>Aktion</th></tr>\n";

while($row=$res->fetch_assoc()) {
	echo "<tr><td>{$row["id"]}</td><td>{$row["username"]}</td><td>{$row["skypename"]}</td><td><a href='?action=edit&id={$row["id"]}'>edit</a> <a href='?action=delete&id={$row["id"]}'>delete</a></td></tr>\n";
}
	echo "<tr><td colspan='3'></td><td><a href='?action=insert'>New</a></td></tr>\n";

echo "</table>";

}

?>
