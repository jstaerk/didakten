<?php
$mysql=new mysqli("127.0.0.1", "root", "", "test");


if ($_REQUEST['action']=="edit") {
	echo "<a href='?'>zur�ck</a><br>";

	
	$res=$mysql->query("SELECT * FROM nutzer WHERE id={$_REQUEST['id']}");
	if(!$res) {
		die("Maschin kaputt in Zeile ".__LINE__." von ".__FILE__);
	}

$row=$res->fetch_assoc();
	echo "ID {$row["id"]}<br>Nutzername: {$row["username"]}<br>Skype: {$row["skypename"]}\n";



} else {

$res=$mysql->query("SELECT * FROM nutzer");
if(!$res) {
	die("Maschin kaputt in Zeile ".__LINE__." von ".__FILE__);
}



echo "<table>";
echo "<tr><th>ID</th><th>Nutzername</th><th>Skype</th><th>Aktion</th></tr>\n";

while($row=$res->fetch_assoc()) {
	echo "<tr><td>{$row["id"]}</td><td>{$row["username"]}</td><td>{$row["skypename"]}</td><td><a href='?action=edit&id={$row["id"]}'>edit</a></td></tr>\n";
}
echo "</table>";

}

?>
