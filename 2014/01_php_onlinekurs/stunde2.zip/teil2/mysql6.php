<?php
$mysql=new mysqli("127.0.0.1", "root", "", "test");

if ($_REQUEST['action']=="login") {


	$res=$mysql->query("SELECT * FROM nutzer WHERE username='".$mysql->real_escape_string($_REQUEST['username'])."' AND passwort=PASSWORD('".$mysql->real_escape_string($_REQUEST['passwort'])."')");

	if ($res->num_rows>0){
		die("OK");
	} else {
		die("Denk nicht mal dran, fremder");
	} 

} else {

	echo "
	<form method='post'>Nutzername: <input type='text' name='username' value='{$row["username"]}'>
	<br>Password: <input type='password' name='passwort' value=''><br>
	<input type='hidden' name='action' value='login'>
	<input type='submit'>
	</form>\n";

}

?>
