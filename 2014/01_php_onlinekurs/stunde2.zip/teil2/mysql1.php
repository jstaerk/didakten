<?php
$mysql=new mysqli("127.0.0.1", "root", "", "test");

$res=$mysql->query("SELECT * FROM nutzer");
if(!$res) {
	die("Maschin kaputt in Zeile ".__LINE__." von ".__FILE__);
}

echo "<table>";
echo "<tr><th>ID</th><th>Nutzername</th><th>Skype</th></tr>\n";

while($row=$res->fetch_assoc()) {
echo "<tr><td>{$row["id"]}</td><td>{$row["username"]}</td><td>{$row["skypename"]}</td></tr>\n";
}
echo "</table>";


?>
