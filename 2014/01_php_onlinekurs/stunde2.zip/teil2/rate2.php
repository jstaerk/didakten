<?php
/**
 * Created by PhpStorm.
 * User: jstaerk
 * Date: 30.03.14
 * Time: 18:34
 */
function neueSuche() {
    $_SESSION['gesuchte']=rand(1,9);

}
function zweiNachkommaStellen($zahl) {
    return round($zahl*100)/100;// auf round(*100)/100-> auf 2 nachkommestellen runden

}

session_start();

if ($_REQUEST['zahl']==999) {
    unset($_SESSION['versuche']);
    unset($_SESSION['erratene']);
    unset($_SESSION['gesuchte']);

}

$nachrichtstext="";
$neutext="";
$trefferquote="unbekannt";

if (!isset($_SESSION['gesuchte'])) {
    /*erstes betreten der Seite*/
    $_SESSION['versuche']=0;
    $_SESSION['erratene']=0;
    neueSuche();

} else {
    $_SESSION['versuche']++;

    if ((!ctype_digit($_REQUEST['zahl']))||(($_REQUEST['zahl']<1)||($_REQUEST['zahl']>9)&&($_REQUEST['zahl']==999))) {
        $nachrichtstext="Deine Eingabe ist keine Zahl im Bereich zwischen 1 und 9";

    } else if ($_REQUEST['zahl']>$_SESSION['gesuchte']) {
        $nachrichtstext="Deine Zahl ({$_REQUEST['zahl']}) ist gr&ouml;&szlig;er als die zu erratende Zahl";

    } else if ($_REQUEST['zahl']<$_SESSION['gesuchte']) {
        $nachrichtstext="Deine Zahl ({$_REQUEST['zahl']}) ist kleiner als die zu erratende Zahl";

    } else {
        $_SESSION['erratene']++;
        $nachrichtstext="Gl&uuml;ckwunsch. Deine Zahl ({$_REQUEST['zahl']}) ist die zu erratende Zahl";
        $neutext="N&auml;chste Zahl erraten:";
        neueSuche();
    }
    if ($_SESSION['versuche']==0) { // division by zero vermeiden
        $trefferquote="0%";
    } else {
        $bruchteil=$_SESSION['erratene']/$_SESSION['versuche'];
        $trefferquote=zweiNachkommaStellen($bruchteil*100)."%"; // zum prozent berechnen: *100
    }

}



?>
<html>

<head>
    <style type="text/css">
        h1,h2 {text-align:center}
        div {margin-left:10%}
    </style>
</head>
<body>
<h1>Zahlenratespiel</h1>
<h2>Errate eine Zahl zwischen 1 und 9</h2>
<div>
<?php echo $_SESSION['versuche']; ?> Versuche<br/>
<?php echo $_SESSION['erratene']; ?> bereits erratene Zahlen<br/>
Trefferquote: <?php echo $trefferquote; ?> <br/>
<h2><?php echo $nachrichtstext; ?></h2><br/>
</div>
<form>
<div style="width: 300px; float:left">
    <?php echo $neutext; ?> Deine Zahl
</div>
<div style="width: 100px; float:left">
    <input type='radio' name="zahl" value="1">1<br/>
    <input type='radio' name="zahl" value="2">2<br/>
    <input type='radio' name="zahl" value="3">3<br/>
    <input type='radio' name="zahl" value="4">4<br/>
    <input type='radio' name="zahl" value="5">5<br/>
    <input type='radio' name="zahl" value="6">6<br/>
    <input type='radio' name="zahl" value="7">7<br/>
    <input type='radio' name="zahl" value="8">8<br/>
    <input type='radio' name="zahl" value="9">9<br/>
</div>
<div style="width: 100px; float:left">
    <input type="submit" value="raten">
</div>

</form>
</body>
</html>

