<?php
/**
 * Created by PhpStorm.
 * User: jstaerk
 * Date: 11.04.14
 * Time: 15:40
 */
function isAuth() {
    return isset($_SESSION['username']);

}

function enforceAuth() {
    if (!isAuth()) {
        header("Location: mysql6.php?redir=".urlencode($_SERVER['REQUEST_URI']));
        die();
    }
}

?>
